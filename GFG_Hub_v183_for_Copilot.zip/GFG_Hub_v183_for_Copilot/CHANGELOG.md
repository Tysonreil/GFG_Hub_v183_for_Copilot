# GFG Connect (Insurance Hub) — v183 hand-off for GitHub Copilot

**Current build:** v183 · platform version id `1792190971-b35d` · published 2026-10-16
**Patch chain verified:** every patch below applies cleanly in order (v155 → v183), and the result is byte-identical to `index.html`.

## What's in this folder
| File | Use |
|---|---|
| `index.html` | **Full current source of the live Hub (v183).** Easiest path: replace the Hub file in the repo with this. |
| `CUMULATIVE_v155_to_v183.diff` | One combined patch from v155 to v183, if the repo is at v155. |
| `patches/` | Per-release patches in order, for when the repo is somewhere between v155 and v183. |
| `db_rules.json` | The 49 database collections and access rules the page expects (2 new in v182–v183: `claim-reviews`, `hub-feedback`). |
| `CHANGELOG.md` | This file. |

## Prompt to give Copilot
> This folder is the latest build (v183) of our Hub page `index.html`, plus the change log and patches since v155. Compare it to our repo's current Hub file. Find which version the repo matches (search for the function names listed under each version below; e.g. `hubTypingGuard` = v183, `rptRecon` = v182, `msRiskProfile` = v181, `msVinDecode` = v177). Then apply the remaining patches in order with `git apply`, or replace the file with `index.html` if the repo has no custom edits of its own. Keep any repo-only changes (login-v2.html, connect.trustgfg.com hosting, OneDrive/email wiring) and tell me about any conflicts instead of overwriting them. Also add any collections in `db_rules.json` our backend doesn't have yet.

## Notes for the GitHub build
- `index.html` is the page body as the Artifact host serves it. The host wraps it in its own `<!doctype><html><head>` and provides the `window.claude` runtime (db, assets, downloads, sample/Claude, user profile). The GitHub build needs its own shim for that runtime. Don't copy any host-specific wrapper.
- Patch paths are `a/index.html` → `b/index.html`. Apply with `git apply patches/NN_*.diff` from the folder that holds the Hub file, or rename the path if the repo file is named differently.
- `03_v161-p2.diff` is the second half of the v161 patch (it was split for size). Apply `02` and then `03`.
- Some steps covered several publishes at once (v163–v170, v176–v177, v178–v181). Those are single patches.

## Patch order
| Patch | Versions | Date | Version id |
|---|---|---|---|
| `patches/01_v156.diff` | v155 → v156 | 2026-10-08 | `1791418898-6692` |
| `patches/02_v161-p1.diff` | v156 → v161 | 2026-10-09 | `1791501918-1cce` |
| `patches/03_v161-p2.diff` | v156 → v161 | 2026-10-09 | `1791501918-1cce` |
| `patches/04_v162.diff` | v161 → v162 | 2026-10-10 | `1791559884-5266` |
| `patches/05_v170.diff` | v162 → v170 | 2026-10-13 | `1791841515-7595` |
| `patches/06_v171.diff` | v170 → v171 | 2026-10-13 | `1791912652-5569` |
| `patches/07_v172.diff` | v171 → v172 | 2026-10-13 | `1791920169-749e` |
| `patches/08_v173.diff` | v172 → v173 | 2026-10-13 | `1791926525-f457` |
| `patches/09_v174.diff` | v173 → v174 | 2026-10-13 | `1791927066-e646` |
| `patches/10_v175.diff` | v174 → v175 | 2026-10-13 | `1791928161-9047` |
| `patches/11_v177.diff` | v175 → v177 | 2026-10-14 | `1791946728-24b0` |
| `patches/12_v181.diff` | v177 → v181 | 2026-10-15 | `1792021079-d75a` |
| `patches/13_v182.diff` | v181 → v182 | 2026-10-16 | `1792104577-0df9` |
| `patches/14_v183.diff` | v182 → v183 | 2026-10-16 | `1792190971-b35d` |

## What changed, by version
### v156 (from v155) — 2026-10-08
`patches/01_v156.diff`

Client profile > expanded policy: binder, invoice, payment receipt and policy files saved in Bound Policies now show in the Policy documents folder (tagged, with open links); uploads to Policy documents / Endorsements unchanged; the expanded policy now fits the visible width so Professional Liability limits and the documents/notes columns are no longer cut off (crmBpFiles, crmDocFoldersHtml, crmPolicyDetailHtml, crmFitPolDetails; CSS).

### v161 (from v156) — 2026-10-09
`patches/02_v161-p1.diff`

Covers all versions published since v156 (v157–v161). Renewals gained holder verification, a separate remarketing step (renewal decision, renewal packet/email, outcome, incumbent comparison) and a renewal workbook download; GFG Connect Market Submissions gained proposal quote upload, a client-ready overview (coverage sections, recommendations, pending items), carrier fillable-application filling, a quick quote summary, quote checks, and a client follow-up checklist/email, plus vehicle-schedule import with VIN checks. Functions: 94 added (e.g. riFlowHtml, riDecisionHtml, riPacketHtml, riOutcomeHtml, msRemarketPanelHtml, msPropUploadHtml, ovCovSections, msCapp*, msQuickQuote, msQc*, msFu*, msParseSchedule, msVinCheck), 44 changed (e.g. buildProposalPreviewHtml, msBuildOverview, msProposalStepHtml, msAppsStepHtml, msQuoteRead, riCaseHtml), none removed; no file or db-rule changes (46 rules).

### v162 (from v161) — 2026-10-10
`patches/04_v162.diff`

Bound Policies now sends GFG's own policy delivery email: the 'Send policy' email uses a new editable 'Delivery email template' (saved to ms-settings/bp-delivery-email) with [Client's First Name], [Policy Type], [Insurance Company] and effective/expiration dates filled in, and staff can upload the carrier's certificate of insurance alongside the policy, with an 'Attach to the email' checklist listing both files. Functions added: bpDeliveryType, bpCertReceived, fill; changed: bpDeliveryMsg, bpPolicyReceived, bpTplHtml, bpWelcomeMsg, wire, copyRow, cqGoto, msX161Input. No file or db-rule changes.

### v170 (from v162) — 2026-10-13
`patches/05_v170.diff`

Covers all versions published since v162 (v163–v170, only the latest captured; per-version notes in the project). Bound Policies gains a policy check (issued policy vs binder and signed quote, broker correction email, extra delivery attachments) and PHLY bond invoices are handled as agency bill; Scorecards/Sales count bond sales and same-department cross-sales and no longer wipe a weekly entry; Market Submissions keeps typing focus; client-profile Quote summary reads scrambled/image PDF pages with Claude (smartPdfText), re-reads old uploads on Auto-fill and shows 'Quote pending' instead of $0. Functions: new bpRunCheck, bpCompare, bpPolicyText, bpReadDoc, carAgencyBill*, bonusSameDept, rsRefreshFileText, rsClientSeed, msFocusKey (+~45 more); changed rsAutofill, buildProposalPreviewHtml, saveEntry, renderScorecards, bonusItems, bpDeliveryMsg, renderMs, crmProfileHtml (+~37). No file or db-rule changes.

### v171 (from v170) — 2026-10-13
`patches/06_v171.diff`

Market Submissions intake (Tyson's Magical Maids screenshots): Fill from notes & files open by default; the separate vehicle/driver import button is gone — Excel/CSV vehicle or driver lists dropped in the upload box are read row by row (msScheduleFromFile, msParseSchedule) and fill blank fields (msApplySchedule), with NowCerts-style header matching (msSchedYmm) and VIN-less vehicles matched on year/make/model (msRowMatch). Logged by a working session on 10/13. No db rule changes.

### v172 (from v171) — 2026-10-13
`patches/07_v172.diff`

Client profile › Policies: every policy can be edited in place (pencil next to the policy number, or Edit policy in the expanded row) — number, line of business, carrier, MGA/broker, dates, status, premium, fees, total, agent and limits by coverage part with standard-limit presets. Edits save where the policy lives: profile-added policies in crm-clients.accounts[], Bound Policies records in bound-policies (carrier/broker/agent/fees stay read-only there), and renewal-book / Comparion / Sales-sheet rows as a per-policy override in crm-clients.polEdits. The expanded policy shows a Limits card, and the list shows a headline limit under the line of business. + Add › Insurance/Benefits policy opens the same form. Functions: new crmPolEditHtml, crmPolLimitsHtml, crmPolHeadline, crmPeSave, crmApplyPolEdit (+9 helpers); changed crmAccounts, crmPolState, crmPoliciesListHtml, crmPolicyDetailHtml, crmMenuHtml, crmOpenProfile. No db rule changes.

### v173 (from v172) — 2026-10-13
`patches/08_v173.diff`

Sales: new-business credit is now per line of business (Tyson 10/13). Each new line written for a client counts as a sale for its producer; a rewrite of a line the client already had (same client, same line, any producer) shows 'rewrite — not counted' unless a lost-client entry shows the client inactive 365+ days, or the log form's new 'Counts as new business' override says otherwise (activities.newBiz/newBizReason). Client-level KPIs (new clients, cross-sales, insurance new accounts) still count a client once. Logging extra lines: closed insurance/benefits rows get '+ Line' (main table and producer detail) which opens the log form prefilled for that client; typing an existing client's name no longer switches the department away from Commercial Insurance or blocks a second Commercial Insurance line; Log activity on a closed sale keeps its sold date. Producer detail shows the line of business. Functions: new markRewrites, lobOf, lobKey, priorLine, syncNewBiz; changed render, crossOutside, deptSeries, openPerson, openLog, linkToGroup, renderClientMatch, rptProducer, save handler. No db rule changes.

### v174 (from v173) — 2026-10-13
`patches/09_v174.diff`

GGOB bonus pool: a P&C commercial client that adds health / group benefits is a new line in a different department and counts (Tyson 10/13). bonusSameDept now compares bonusDept(a), which treats medical/dental/vision/life/STD/LTD lines logged under Commercial Insurance as Group Benefits, so they are never excluded as same-department cross-sales. No db rule changes.

### v175 (from v174) — 2026-10-13
`patches/10_v175.diff`

P&C Renewal Center (Kimber): the policy / bond number shows as a small monospace line under the insured name in the period tables and in search results, no new column; click it to copy. A renewal-rows.renewedPolicy field, when set, shows as 'expiring → renewal #'. The client search also matches policy numbers (4+ characters, punctuation ignored). Functions: new rcPolicyHtml; changed renderRow, renderSearchRow, renewalSearchMatches. No db rule changes.

### v177 (from v175) — 2026-10-14
`patches/11_v177.diff`

Covers all versions published since v175 (v176 + v177 per project build notes, plus a Sales Reports update). Market Submissions: the separate Underwriting step is merged into the Applicant step (msStep 'uw' now redirects to 'applicant'; msApplicantStepHtml renders msUwStepHtml), and typing/pasting a 17-character VIN in a vehicle row now decodes it on the page — check digit, model year and maker fill blank Year/Make, mismatches are flagged, never overwritten — with a 'Fill from VINs' button and a copyable NHTSA-decode request for Claude (new msVinDecode, msVinFillRow/All, msVinHintHtml, msVinOnInput, msVinClaudeRequest, MS_WMI table). Sales Reports: Monthly Sales Summary gains 'This quarter, by month' and 'Year, quarter by quarter' comparison views and the Bonus Pool Statement gains an 'All quarters' period (new splitRanges, rptMonthlySplit, rptBonusYear; periodRange, rptMonthly, rptBonus changed). Published files and db rules unchanged (46 rules).

### v181 (from v177) — 2026-10-15
`patches/12_v181.diff`

Covers all versions published since v177 (labelled v181 to match project build notes: v178 Partners Financials/P&L, v179 carrier commission schedule, v180 renewal applications, v181 input-driven forms/ACORD 127). Staff will notice a Financials (P&L) view with charts on the Partners tab, an owners-only carrier commission schedule on carrier profiles, a 'Renewal applications' path in the Renewal Center that starts an ACORD renewal submission carrying forward last year's answers, and Market Submissions now building an input-driven risk profile (for-hire hauling/towing detection, ACORD 127 questions, underwriter red-flag checks on the Applicant step). Functions added include owFinHtml/owFinChart, carSchedHtml, riStartRenewalApps/riRenewAppsHtml, msRisk/msRiskChecks/msRiskPanelHtml/msRenewalAppsBannerHtml; changed include msUwStepHtml, msAcordQsHtml, msExtract, riDecisionHtml, carCmHtml. New db rule: owner-financials (admin read/write; 47 rules). Published files unchanged.

### v182 (from v181) — 2026-10-16
`patches/13_v182.diff`

Adds a new Claims Review tab under Insurance Central (panel-claims): upload policy and claim documents, Claude tests each route to coverage with form/page citations, lays out the money and negotiation points, compares a refreshed policy against a prior copy, and builds a one-file claim packet PDF; reviews save to a new db collection claim-reviews (note: the stored capability declaration has no claim-reviews rule, so those saves may be refused until the rule is added). Also adds v182 sales & commission reconciliation to the Sales reports (owner-only commission lines matched against logged sales, with ok/waiting/warn/bad tags and a red count badge on the Reports button). Functions touched: new rptRecon, rptReconBody, recMatch, recModel, recNames, recKey, updateRecBadge, cmIsCommission/cmLob/cmEffDate, analyze, buildPacket, compare, renderReport and other Claims Review helpers; changed openReports, runReport, rptMonthly, rptMonthlySplit, monthlyAgg, resolveNames, crmSyncSoon, onKey. Covers all versions published since v181 (version id 1792021079-d75a -> 1792104577-0df9). Published files and the 47 db rules are unchanged.

### v183 (from v182) — 2026-10-16
`patches/14_v183.diff`

v183: Hub-wide typing guard — screens that rebuild on live data no longer wipe text someone is mid-typing (focus, caret and unsaved text are restored; Market Submissions editor skipped since it already restores). New floating "Report a problem / request" button and dialog that saves to a new hub-feedback collection with on-screen context (owners see all items with an open-count badge and can resolve; staff see their own). GL L&I tracker status dropdown now rolls back on a failed save and shows a permission message. Functions touched: updateLniClientStatus (changed); new hubTypingGuard (keyOf, fields, capture, restore, restoreInner…) and hubFeedback (init, context, openDialog, paint, paintBadge, act, resolve, mount…). DB rules 47→49: claim-reviews and hub-feedback added. Published files unchanged.

## Hub-wide behaviors to keep (from v183 state notes)
- **Typing guard (v183):** a wrapped `Element.prototype.innerHTML` setter keeps focus, caret and unsaved typing when a screen rebuilds. Don't add per-screen focus fixes. `#ms-body` (Market Submissions) keeps its own v164 logic.
- **No native pop-ups:** use `hubToast(msg, isErr)` and `await hubDialog({...})`. `alert()` is routed to a red toast.
- **Report a problem (v183):** floating button saves to `hub-feedback`.
- **Query cap:** every `.limit()` must be ≤ 1000.
- Keep `PROPOSAL_TEAM_ROSTER` / `PROPOSAL_FOOTER_CONTACT_LINE` / `PROPOSAL_LEGAL_*` in sync with `generate_overview.py`.
